function handleGroupEvent(event) {
  console.log('Group event:', event)
}

module.exports = handleGroupEvent