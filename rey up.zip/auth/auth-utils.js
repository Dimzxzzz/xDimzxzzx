function generateAuthToken() {
  return 'AUTH_TOKEN_SAMPLE'
}

module.exports = { generateAuthToken }