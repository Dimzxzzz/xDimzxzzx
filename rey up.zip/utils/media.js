function downloadMediaMessage(msg) {
  console.log('Downloading media:', msg)
}

module.exports = { downloadMediaMessage }