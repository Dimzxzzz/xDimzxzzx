const logger = console

module.exports = logger
