const proto = {
  Message: (content) => ({ message: content })
}

module.exports = { proto }